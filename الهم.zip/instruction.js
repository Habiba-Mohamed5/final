window.onload = function() {
    const audio = document.getElementById("audio");
    audio.play();

    audio.onended = function() {
        window.location.href = "choose.html";
        };

    };